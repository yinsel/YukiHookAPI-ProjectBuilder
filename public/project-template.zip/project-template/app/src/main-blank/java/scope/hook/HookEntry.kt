package {PACKAGE_NAME}.hook

import com.highcapable.yukihookapi.annotation.xposed.InjectYukiHookWithXposed
import com.highcapable.yukihookapi.hook.factory.configs
import com.highcapable.yukihookapi.hook.factory.encase
import com.highcapable.yukihookapi.hook.xposed.proxy.IYukiHookXposedInit

@InjectYukiHookWithXposed{YUKIHOOKAPI_ANNOTATION}
class HookEntry : IYukiHookXposedInit {

    override fun onInit() = configs {
        {YUKIHOOKAPI_CONFIGS}
    }

    override fun onHook() = encase {
        // Your code here.
    }
}