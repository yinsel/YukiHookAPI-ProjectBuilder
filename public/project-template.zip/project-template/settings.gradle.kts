pluginManagement {
    repositories {
        // gradlePluginPortal()
        maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
        // google()
        maven { url = uri("https://maven.aliyun.com/repository/google/") }
        // mavenCentral()
        maven { url = uri("https://maven.aliyun.com/repository/public/") }
        mavenCentral()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        // google()
        maven { url = uri("https://maven.aliyun.com/repository/google/") }
        // mavenCentral()
        maven { url = uri("https://maven.aliyun.com/repository/public/") }
        maven("https://api.xposed.info/")
    }
}

plugins {
    id("com.highcapable.gropify") version "{GROPIFY_VERSION}"
}

gropify {
    rootProject {
        common {
            isEnabled = false
        }
    }
}

rootProject.name = "{PROJECT_NAME}"

include(":app")